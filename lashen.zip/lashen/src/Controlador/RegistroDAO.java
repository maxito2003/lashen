/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.Registro;

/**
 *
 * @author laura
 */
public class RegistroDAO {
     PreparedStatement ps;
    ResultSet rs;
    Connection con;
    
    Conexion sc = new Conexion();

    
    public boolean guardar(Registro r){
    boolean guarda=false;
    con=sc.conectar();
     String sql="insert into registros values(?,?,?,?,?)";
            try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, r.getId_usuario());
            ps.setString(2, r.getUsuario());
            ps.setString(3, r.getCorreo());
            ps.setString(4, r.getContrasena());
           // ps.setString(5, r.getNombre_empresa());
            //ps.setString(6, r.getDireccion());
            ps.setString(5, r.getFoto());
            int g=ps.executeUpdate();
            if(g>0){
            guarda=true;
                JOptionPane.showMessageDialog(null, "TU REGISTRO SE HA GUARDADO");
            }else{
                JOptionPane.showMessageDialog(null, "TU REGISTRO NO SE HA GUARDADO");
            }
            con.close();
            ps.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "ERROR AL GUARDAR" + e.getMessage());
        }
    return guarda;
    }
    
    public boolean consultar(Registro r){
    boolean consulta=false;
    con=sc.conectar();
     String sql="select * from registros where id_usuario=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, r.getId_usuario());
          rs=ps.executeQuery();
            if(rs.next()){
            consulta=true;
            
            r.setId_usuario(rs.getInt(1));
            r.setUsuario(rs.getString(2));
            r.setCorreo(rs.getString(3));
             r.setContrasena(rs.getString(4));
              //r.setNombre_empresa(rs.getString(5));
               //r.setDireccion(rs.getString(6));
                r.setFoto(rs.getString(5));
               
            }else{
                JOptionPane.showMessageDialog(null, "TU REGISTRO NO SE HA CONSULTADO");
            }
            con.close();
            ps.close();
            rs.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "ERROR AL CONSULTAR");
        }
    
    
    return consulta;
    }
    
    
    public boolean actualizar(Registro r){
    boolean actualiza=false;
    con=sc.conectar();
     String sql="update registros set usuario=?, correo=?, contrasena=?, foto=? where id_usuario=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setString(1, r.getUsuario());
            ps.setString(2, r.getCorreo());
            ps.setString(3, r.getContrasena());
            //ps.setString(4, r.getNombre_empresa());
          //  ps.setString(5, r.getDireccion());
            ps.setString(4, r.getFoto());
             ps.setInt(5, r.getId_usuario());
            int a=ps.executeUpdate();
            if(a>0){
            actualiza=true;
                JOptionPane.showMessageDialog(null, "TU REGISTRO SE HA ACTUALIZADO");
            }else{
                JOptionPane.showMessageDialog(null, "TU REGISTRO NO SE HA ACTUALIZADO");
            }
            con.close();
            ps.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "ERROR AL ACTUALIZAR");
        }
    return actualiza;
    }
    
     public boolean eliminar(Registro r){
    boolean eliminado=false;
    con=sc.conectar();
     String sql="delete from registros where id_usuario=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, r.getId_usuario());
            int e=ps.executeUpdate();
            if(e>0){
            eliminado=true;
                JOptionPane.showMessageDialog(null, "TU REGISTRO SE HA ELIMINADO");
            }else{
                JOptionPane.showMessageDialog(null, "TU REGISTRO NO SE HA ELIMINADO");
            }
            con.close();
            ps.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "ERROR AL ELIMINAR");
        }
    return eliminado;
    }
    
    
}
