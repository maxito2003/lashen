/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Login;

/**
 *
 * @author laura
 */
public class LoginDAO {
    public Login validar(String u, String c){
        Login usuario=null;
        String sql="SELECT * FROM registros where usuario=? and contrasena=?";
        Conexion sc =new Conexion();
        PreparedStatement ps=null;
        ResultSet rs=null;
        try {
            Connection conn= sc.conectar();
            ps=conn.prepareStatement(sql);
            ps.setString(1, u);
            ps.setString(2, c);
            rs=ps.executeQuery();
            if(rs.next()){
                usuario= new Login();
                usuario.contrasena=rs.getString("contrasena");
                //usuario.id_usuario=rs.getInt("id_usuario");
                usuario.usuario=rs.getString("usuario");
            }
        } catch (SQLException e) {
            System.out.println("Error " +e);
        }
        
        return usuario;
        
    
}
    
    
    
    
}
