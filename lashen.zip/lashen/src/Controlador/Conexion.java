/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author laura
 */
public class Conexion {
        private String base = "lashen"; 
 private String url = "jdbc:mysql://localhost:3306/lashen";
   private String user = "root"; 
   private String password = ""; 
   private Connection con = null;

   public Connection conectar() {
       try { 
           Class.forName("com.mysql.cj.jdbc.Driver");
           con = DriverManager.getConnection(url, user, password); 
       } catch (ClassNotFoundException | SQLException e) {
           System.err.println(e); 
       }
       return con;
   } //conectar
    
}
