/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.Empresa;

/**
 *
 * @author laura
 */
public class EmpresaDAO {
      
    PreparedStatement ps;
    ResultSet rs;
    Connection con;
    Conexion sc = new Conexion();
    
    public boolean guardar(Empresa em){
    boolean guarda=false;
    con=sc.conectar();
     String sql="insert into empresa values(?,?,?,?,?,?)";
            try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, em.getId_empresa());
            ps.setString(2, em.getNombre_empresa());
            ps.setString(3, em.getPropietario());
            ps.setString(4, em.getDireccion());
            ps.setDouble(5, em.getEgresos());
            ps.setString(6, em.getFecha_egreso());
            int g=ps.executeUpdate();
            if(g>0){
            guarda=true;
                JOptionPane.showMessageDialog(null, "TU EMPRESA SE HA GUARDADO");
            }else{
                JOptionPane.showMessageDialog(null, "TU EMPRESA NO SE HA GUARDADO");
            }
            con.close();
            ps.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "ERROR AL GUARDAR");
        }
    return guarda;
    } 
    
    public boolean consultar(Empresa em){
    boolean consulta=false;
    con=sc.conectar();
     String sql="select * from empresa where id_usuario=?";
        try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, em.getId_empresa());
          rs=ps.executeQuery();
            if(rs.next()){
            consulta=true;
            em.setId_empresa(rs.getInt(1));
            em.setNombre_empresa(rs.getString(2));
            em.setDireccion(rs.getString(3));
            em.setPropietario(rs.getString(4));
            em.setEgresos(rs.getDouble(5));
            em.setFecha_egreso(rs.getString(6));
            }else{
                JOptionPane.showMessageDialog(null, "TU EMPRESA NO SE HA CONSULTADO");
            }
            con.close();
            ps.close();
            rs.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "ERROR AL CONSULTAR"+e);
        }
    return consulta;
    }
    
    public boolean actualizar(Empresa em){
    boolean actualizado=false;
    con=sc.conectar();
     String sql="update empresa set nombre_empresa=?, propietario=?, direccion=?, egresos=?, fecha_egresos=? where id_usuario=?";
            try {
            ps=con.prepareStatement(sql);
            ps.setString(1, em.getNombre_empresa());
            ps.setString(2, em.getPropietario());
            ps.setString(3, em.getDireccion());
            ps.setDouble(4, em.getEgresos());
            ps.setString(5, em.getFecha_egreso());
            ps.setInt(6, em.getId_empresa());
            int a=ps.executeUpdate();
            if(a>0){
            actualizado=true;
                JOptionPane.showMessageDialog(null, "TU EMPRESA SE HA ACTUALIZADO");
            }else{
                JOptionPane.showMessageDialog(null, "TU EMPRESA NO SE HA ACTUALIZADO");
            }
            con.close();
            ps.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "ERROR AL ACTUALIZAR");
        }
    return actualizado;
    } 
    
    public boolean eliminar(Empresa em){
    boolean eliminado=false;
    con=sc.conectar();
     String sql="delete from empresa where id_usuario=?";
            try {
            ps=con.prepareStatement(sql);
            ps.setInt(1, em.getId_empresa());
            int el=ps.executeUpdate();
            if(el>0){
            eliminado=true;
                JOptionPane.showMessageDialog(null, "TU EMPRESA SE HA ELIMINADO");
            }else{
                JOptionPane.showMessageDialog(null, "TU EMPRESA NO SE HA ELIMINADO");
            }
            con.close();
            ps.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "ERROR AL ELIMINAR");
        }
    return eliminado;
    } 
}
