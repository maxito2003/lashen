/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author laura
 */
public class Registro {
     public int id_usuario;
    public String usuario;
     public String correo;
      public String contrasena;
       public String nombre_empresa;
        public String direccion;
         public String foto;
         
         //CONSTRUCTOR
         public Registro(){}
         
         //CONSTRUCTOR 

    public Registro(int id_usuario, String usuario, String correo, String contrasena, String nombre_empresa, String direccion, String foto) {
        this.id_usuario = id_usuario;
        this.usuario = usuario;
        this.correo = correo;
        this.contrasena = contrasena;
        this.nombre_empresa = nombre_empresa;
        this.direccion = direccion;
        this.foto = foto;
    }
         
         //getters and setters

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getNombre_empresa() {
        return nombre_empresa;
    }

    public void setNombre_empresa(String nombre_empresa) {
        this.nombre_empresa = nombre_empresa;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
}
