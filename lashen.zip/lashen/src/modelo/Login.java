/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author laura
 */
public class Login {
      
    public int id_usuario;
    
    
    public String usuario;
    public String contrasena;

    public Login(int id_usuario, String usuario, String contrasena) {
        this.id_usuario = id_usuario;
        this.usuario = usuario;
        this.contrasena = contrasena;
    }
    
     public Login() {
    }
    
        
    
    
}
